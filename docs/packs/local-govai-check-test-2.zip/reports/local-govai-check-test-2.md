# Audit report for run `local-govai-check-test-2`

run_id=local-govai-check-test-2
bundle_sha256=cc0296d709380d8233945cdd2e9bccec752e76cce6748912a51714d7f5d1098b
policy_version=v0.5_dev

## Summary

### Canonical identifiers (bundle)

- `ai_system_id`: `aigov_poc`
- `dataset_id`: `dataset_iris_v1`
- `model_version_id`: `model_version_01_local-govai-check-test-2`
- `primary_risk_id`: `risk_01_local-govai-check-test-2`
- `risk_ids`: `risk_01_local-govai-check-test-2`

- System: `aigov_poc`
- Actor: `monika`
- Policy version: `v0.5_dev`
- Evidence bundle: `docs/evidence/local-govai-check-test-2.json`
- Evidence bundle SHA256: `cc0296d709380d8233945cdd2e9bccec752e76cce6748912a51714d7f5d1098b`
- Model artifact (reported): `python/artifacts/model_local-govai-check-test-2.joblib`

## Traceability

| Item | Value |
|---|---|
| Dataset | `iris` |
| Dataset fingerprint | `c45a292b1d906e5d24213ec35f8123803f1b362a5a5ce5a857e242e1e34a5362` |
| Dataset version | `v1` |
| Dataset governance commitment | `6cedeca7debccd0deae7954eb2a109f9da73a069c82929b211b6b782bb4b268a` |
| Governance status | `governed` |
| Rows | `150` |
| Features | `4` |

## Risk review register

| Risk ID | Risk class | Severity | Likelihood | Status | Owner | Mitigation | Review decision | Reviewer | Justification |
|---|---|---:|---:|---|---|---|---|---|---|
| `risk_01_local-govai-check-test-2` | `high` | `4.0` | `0.3` | `mitigated` | `risk_owner` | `Mitigation applied: restrict intended use to the governed demo scope + enforce passed evaluation gate.` | `approve` | `risk_officer` | `Dataset governance commitment verified; evaluation threshold and human oversight requested before promotion.` |

## Evaluation gate

| Metric | Value | Threshold | Passed |
|---|---:|---:|---|
| `accuracy` | `0.9666666666666668` | `0.8` | `True` |

## Human approval gate

| Scope | Decision | Approver | Justification |
|---|---|---|---|
| `model_promoted` | `approve` | `compliance_officer` | `metrics meet threshold and dataset governance commitment verified` |

### Approval linkage fields

- Assessment ID: `assessment_01_local-govai-check-test-2`
- Risk ID: `risk_01_local-govai-check-test-2`
- Dataset governance commitment: `6cedeca7debccd0deae7954eb2a109f9da73a069c82929b211b6b782bb4b268a`

## Promotion

- Promotion reason: `approved_by_human`
- Artifact path: `python/artifacts/model_local-govai-check-test-2.joblib`
- Approved human event id: `ha_local-govai-check-test-2`

## Event timeline

| Time (UTC) | Event | Event id |
|---|---|---|
| `2026-04-28T14:49:38.131787Z` | `run_started` | `482a0751-4778-44e7-9e4f-04f5379d2a36` |
| `2026-04-28T14:49:38.272337Z` | `data_registered` | `bf8fc52d-c0cc-4321-99b6-98c3a5db98bf` |
| `2026-04-28T14:49:38.306108Z` | `model_trained` | `1b7de1bf-7cba-4192-8060-2f9793fed4df` |
| `2026-04-28T14:49:38.309197Z` | `evaluation_reported` | `3ca4e2a0-f434-4056-a145-c530f4d60704` |
| `2026-04-28T14:49:38.312255Z` | `model_trained` | `03aaaee8-dba2-45d2-aaef-0599cd239958` |
| `2026-04-28T14:49:38.314865Z` | `risk_recorded` | `1e0aaf33-b3d2-4fcd-bd09-eb71ae427978` |
| `2026-04-28T14:49:38.317963Z` | `risk_mitigated` | `df210dfc-589f-4787-b577-9c35cc2592a8` |
| `2026-04-28T14:49:38.321948Z` | `risk_reviewed` | `e9c49519-016f-4910-8546-f96e068505db` |
| `2026-04-28T14:49:38.517630Z` | `human_approved` | `ha_local-govai-check-test-2` |
| `2026-04-28T14:49:39.669869Z` | `model_promoted` | `mp_after_approval_local-govai-check-test-2` |

## Audit log reference

- Log path (reported by server): `rust/audit_log__default.jsonl`
