# Audit report for run `local-govai-check-test`

run_id=local-govai-check-test
bundle_sha256=3a18c9d176c4a3b5660231a9001d7eeb69995d5d5e1dc05eb95a61ad12292fe6
policy_version=v0.5_dev

## Summary

### Canonical identifiers (bundle)

- `ai_system_id`: `aigov_poc`
- `dataset_id`: `dataset_iris_v1`
- `model_version_id`: `model_version_01_local-govai-check-test`
- `primary_risk_id`: `risk_01_local-govai-check-test`
- `risk_ids`: `risk_01_local-govai-check-test`

- System: `aigov_poc`
- Actor: `monika`
- Policy version: `v0.5_dev`
- Evidence bundle: `docs/evidence/local-govai-check-test.json`
- Evidence bundle SHA256: `3a18c9d176c4a3b5660231a9001d7eeb69995d5d5e1dc05eb95a61ad12292fe6`
- Model artifact (reported): `python/artifacts/model_local-govai-check-test.joblib`

## Traceability

| Item | Value |
|---|---|
| Dataset | `iris` |
| Dataset fingerprint | `c45a292b1d906e5d24213ec35f8123803f1b362a5a5ce5a857e242e1e34a5362` |
| Dataset version | `v1` |
| Dataset governance commitment | `6cedeca7debccd0deae7954eb2a109f9da73a069c82929b211b6b782bb4b268a` |
| Governance status | `governed` |
| Rows | `150` |
| Features | `4` |

## Risk review register

| Risk ID | Risk class | Severity | Likelihood | Status | Owner | Mitigation | Review decision | Reviewer | Justification |
|---|---|---:|---:|---|---|---|---|---|---|
| `risk_01_local-govai-check-test` | `high` | `4.0` | `0.3` | `mitigated` | `risk_owner` | `Mitigation applied: restrict intended use to the governed demo scope + enforce passed evaluation gate.` | `approve` | `risk_officer` | `Dataset governance commitment verified; evaluation threshold and human oversight requested before promotion.` |

## Evaluation gate

| Metric | Value | Threshold | Passed |
|---|---:|---:|---|
| `accuracy` | `0.9666666666666668` | `0.8` | `True` |

## Human approval gate

| Scope | Decision | Approver | Justification |
|---|---|---|---|
| `model_promoted` | `approve` | `compliance_officer` | `metrics meet threshold and dataset governance commitment verified` |

### Approval linkage fields

- Assessment ID: `assessment_01_local-govai-check-test`
- Risk ID: `risk_01_local-govai-check-test`
- Dataset governance commitment: `6cedeca7debccd0deae7954eb2a109f9da73a069c82929b211b6b782bb4b268a`

## Promotion

- Promotion reason: `approved_by_human`
- Artifact path: `python/artifacts/model_local-govai-check-test.joblib`
- Approved human event id: `ha_local-govai-check-test`

## Event timeline

| Time (UTC) | Event | Event id |
|---|---|---|
| `2026-04-28T14:10:42.375488Z` | `run_started` | `f03b8008-7218-4d3e-a342-e15b81c62799` |
| `2026-04-28T14:10:42.557602Z` | `data_registered` | `f75e90eb-5cd5-4d1b-977e-aafcdfdc5be6` |
| `2026-04-28T14:10:42.600090Z` | `model_trained` | `070c4532-f31a-42a7-97b0-4a5fb8f359c6` |
| `2026-04-28T14:10:42.603452Z` | `evaluation_reported` | `5d89412d-f8cb-42e4-8dd9-630eb77e1b75` |
| `2026-04-28T14:10:42.608589Z` | `model_trained` | `64aebd07-05c7-4e40-b135-c2b8adb4c9a6` |
| `2026-04-28T14:10:42.612518Z` | `risk_recorded` | `720fd622-e5e3-4daa-a447-e3da1e144af8` |
| `2026-04-28T14:10:42.615344Z` | `risk_mitigated` | `0486a2f3-4315-42ba-9cb0-62e49f4dda74` |
| `2026-04-28T14:10:42.618311Z` | `risk_reviewed` | `e43a797b-de0d-4ef6-a8f0-84c5fa02fed8` |
| `2026-04-28T14:10:42.890888Z` | `human_approved` | `ha_local-govai-check-test` |
| `2026-04-28T14:10:44.092774Z` | `model_promoted` | `mp_after_approval_local-govai-check-test` |

## Audit log reference

- Log path (reported by server): `rust/audit_log__default.jsonl`
